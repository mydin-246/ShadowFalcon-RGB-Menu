import React, { useState, useEffect } from 'react';
import { useAuth } from './AuthContext';
import { Game, Post, User } from './types';
import { Download, Users, Plus, MessageSquare, Search, Shield, Zap, TrendingUp, Clock } from 'lucide-react';
import { motion } from 'motion/react';
import { formatDistanceToNow } from 'date-fns';

export default function Home() {
  const { user } = useAuth();
  const [games, setGames] = useState<Game[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);
  const [developers, setDevelopers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [gamesRes, postsRes, devsRes] = await Promise.all([
          fetch('/api/games'),
          fetch('/api/posts'),
          fetch('/api/developers')
        ]);
        setGames(await gamesRes.json());
        setPosts(await postsRes.json());
        setDevelopers(await devsRes.json());
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  if (loading) return <div className="flex items-center justify-center h-screen">Loading...</div>;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-12">
      {/* Developers Section */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Users className="w-5 h-5 text-emerald-500" />
            Featured Developers
          </h2>
        </div>
        <div className="flex gap-4 overflow-x-auto pb-4 no-scrollbar">
          {developers.map((dev) => (
            <motion.div
              key={dev.id}
              whileHover={{ y: -5 }}
              className="flex-shrink-0 w-48 glass rounded-2xl p-4 text-center space-y-3"
            >
              <img
                src={dev.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${dev.name}`}
                alt={dev.name}
                className="w-20 h-20 mx-auto rounded-full bg-zinc-800"
                referrerPolicy="no-referrer"
              />
              <div>
                <h3 className="font-semibold truncate">{dev.name}</h3>
                <p className="text-xs text-zinc-400">1B Subscriptions</p>
              </div>
              <button className="w-full py-1.5 bg-zinc-800 hover:bg-zinc-700 rounded-lg text-xs font-medium transition-colors">
                Follow
              </button>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Latest Games */}
      <section className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Zap className="w-5 h-5 text-yellow-500" />
            Latest Games
          </h2>
          <button className="text-sm text-emerald-500 hover:underline">View All</button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {games.slice(0, 6).map((game) => (
            <GameCard key={game.id} game={game} />
          ))}
        </div>
      </section>

      {/* Top Downloads */}
      <section className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-blue-500" />
            Most Downloaded
          </h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {games.sort((a, b) => b.downloads - a.downloads).slice(0, 4).map((game, idx) => (
            <div key={game.id} className="flex items-center gap-4 glass p-3 rounded-xl">
              <span className="text-2xl font-bold text-zinc-700 w-8">{idx + 1}</span>
              <img src={game.icon} className="w-12 h-12 rounded-lg" alt="" referrerPolicy="no-referrer" />
              <div className="flex-1 min-w-0">
                <h4 className="font-medium truncate text-sm">{game.title}</h4>
                <p className="text-xs text-zinc-500">{game.downloads} downloads</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Developer Posts */}
      <section className="space-y-6">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <MessageSquare className="w-5 h-5 text-purple-500" />
          Developer Updates
        </h2>
        <div className="space-y-4">
          {posts.map((post) => (
            <div key={post.id} className="glass rounded-2xl p-6 space-y-4">
              <div className="flex items-center gap-3">
                <img
                  src={post.developer_avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${post.developer_name}`}
                  className="w-10 h-10 rounded-full bg-zinc-800"
                  alt=""
                  referrerPolicy="no-referrer"
                />
                <div>
                  <h4 className="font-semibold text-sm">{post.developer_name}</h4>
                  <p className="text-xs text-zinc-500 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {formatDistanceToNow(new Date(post.created_at))} ago
                  </p>
                </div>
              </div>
              <p className="text-zinc-300 text-sm leading-relaxed">{post.content}</p>
              {post.image && (
                <img src={post.image} className="w-full h-64 object-cover rounded-xl" alt="" referrerPolicy="no-referrer" />
              )}
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

const GameCard: React.FC<{ game: Game }> = ({ game }) => {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      className="glass rounded-2xl overflow-hidden group"
    >
      <div className="relative h-48">
        <img
          src={`https://picsum.photos/seed/${game.title}/600/400`}
          className="w-full h-full object-cover"
          alt={game.title}
          referrerPolicy="no-referrer"
        />
        <div className="absolute top-3 right-3 flex gap-2">
          {game.type === 'modded' && (
            <span className="px-2 py-1 bg-emerald-500 text-white text-[10px] font-bold rounded uppercase tracking-wider">
              Modded
            </span>
          )}
          <span className="px-2 py-1 bg-black/50 backdrop-blur-md text-white text-[10px] font-bold rounded uppercase tracking-wider">
            {game.size}
          </span>
        </div>
      </div>
      <div className="p-5 space-y-4">
        <div className="flex gap-4">
          <img src={game.icon} className="w-12 h-12 rounded-xl shadow-lg" alt="" referrerPolicy="no-referrer" />
          <div className="flex-1 min-w-0">
            <h3 className="font-bold truncate group-hover:text-emerald-400 transition-colors">{game.title}</h3>
            <p className="text-xs text-zinc-400 truncate">by {game.developer_name}</p>
          </div>
        </div>
        <div className="flex items-center justify-between pt-2 border-t border-white/5">
          <div className="flex items-center gap-1 text-xs text-zinc-500">
            <Download className="w-3 h-3" />
            {game.downloads}
          </div>
          <button className="px-4 py-1.5 bg-emerald-600/20 hover:bg-emerald-600 text-emerald-400 hover:text-white rounded-lg text-xs font-bold transition-all">
            Download
          </button>
        </div>
      </div>
    </motion.div>
  );
}
