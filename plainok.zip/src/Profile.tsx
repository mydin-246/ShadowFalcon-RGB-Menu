import React, { useState } from 'react';
import { useAuth } from './AuthContext';
import { User, Mail, Shield, LogOut, Camera, Settings, AlertTriangle } from 'lucide-react';
import { motion } from 'motion/react';

export default function Profile() {
  const { user, logout } = useAuth();
  const [name, setName] = useState(user?.name || '');
  const [complaint, setComplaint] = useState({ type: 'technical', content: '' });
  const [sending, setSending] = useState(false);

  if (!user) return null;

  const handleSendComplaint = async (e: React.FormEvent) => {
    e.preventDefault();
    setSending(true);
    try {
      await fetch('/api/complaints', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: user.id,
          ...complaint
        }),
      });
      alert('Complaint sent to zoka45362@gmail.com');
      setComplaint({ type: 'technical', content: '' });
    } catch (error) {
      console.error(error);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-8">
      <div className="glass rounded-3xl p-8">
        <div className="flex flex-col md:flex-row items-center gap-8">
          <div className="relative group">
            <img
              src={user.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.name}`}
              className="w-32 h-32 rounded-full bg-zinc-800 border-4 border-zinc-900 shadow-2xl"
              alt=""
              referrerPolicy="no-referrer"
            />
            <button className="absolute bottom-0 right-0 p-2 bg-emerald-600 rounded-full shadow-lg hover:bg-emerald-500 transition-colors">
              <Camera className="w-5 h-5" />
            </button>
          </div>
          <div className="flex-1 text-center md:text-left space-y-4">
            <div>
              <h1 className="text-3xl font-bold">{user.name}</h1>
              <div className="flex items-center justify-center md:justify-start gap-2 text-zinc-500 mt-1">
                <Mail className="w-4 h-4" />
                <span className="text-sm">{user.email}</span>
                <span className="px-2 py-0.5 bg-zinc-800 rounded text-[10px] font-bold uppercase">Private</span>
              </div>
            </div>
            <div className="flex flex-wrap justify-center md:justify-start gap-3">
              <button className="btn-primary flex items-center gap-2">
                <Settings className="w-4 h-4" />
                Edit Profile
              </button>
              <button onClick={logout} className="px-4 py-2 bg-red-600/10 hover:bg-red-600 text-red-500 hover:text-white rounded-lg transition-all flex items-center gap-2">
                <LogOut className="w-4 h-4" />
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="glass rounded-3xl p-8 space-y-6">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Shield className="w-5 h-5 text-blue-500" />
            Account Security
          </h2>
          <div className="space-y-4">
            <div className="p-4 bg-zinc-900/50 rounded-2xl flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm font-semibold">Two-Factor Authentication</p>
                <p className="text-xs text-zinc-500">OTP via Email</p>
              </div>
              <div className="px-3 py-1 bg-emerald-500/20 text-emerald-400 text-[10px] font-bold rounded-full uppercase">Enabled</div>
            </div>
            <div className="p-4 bg-zinc-900/50 rounded-2xl flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm font-semibold">Password Encryption</p>
                <p className="text-xs text-zinc-500">AES-256 Standard</p>
              </div>
              <div className="px-3 py-1 bg-emerald-500/20 text-emerald-400 text-[10px] font-bold rounded-full uppercase">Active</div>
            </div>
          </div>
        </div>

        <div className="glass rounded-3xl p-8 space-y-6">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-yellow-500" />
            Support & Complaints
          </h2>
          <form onSubmit={handleSendComplaint} className="space-y-4">
            <div className="space-y-2">
              <label className="text-xs font-bold text-zinc-500 uppercase">Issue Category</label>
              <select
                value={complaint.type}
                onChange={(e) => setComplaint({ ...complaint, type: e.target.value })}
                className="input-field"
              >
                <option value="technical">Technical Issue</option>
                <option value="game_report">Report a Game</option>
                <option value="security">Security Concern</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-zinc-500 uppercase">Description</label>
              <textarea
                required
                rows={3}
                value={complaint.content}
                onChange={(e) => setComplaint({ ...complaint, content: e.target.value })}
                className="input-field resize-none"
                placeholder="Describe your issue..."
              />
            </div>
            <button
              disabled={sending}
              className="w-full py-3 bg-zinc-800 hover:bg-zinc-700 rounded-xl font-semibold transition-all"
            >
              {sending ? 'Sending...' : 'Submit Complaint'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
