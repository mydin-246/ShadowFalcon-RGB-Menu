import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './AuthContext';
import Home from './Home';
import Search from './Search';
import Auth from './Auth';
import Profile from './Profile';
import DeveloperDashboard from './DeveloperDashboard';
import { Gamepad2, Search as SearchIcon, User as UserIcon, LayoutDashboard, Shield } from 'lucide-react';

function AppContent() {
  const { user, isLoading } = useAuth();
  const location = useLocation();

  if (isLoading) return null;

  return (
    <div className="min-h-screen flex flex-col">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 glass border-b border-white/5 px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 group">
            <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-900/20 group-hover:scale-110 transition-transform">
              <Gamepad2 className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-black tracking-tighter uppercase italic">Plainok</span>
          </Link>

          <div className="hidden md:flex items-center gap-1">
            <NavLink to="/" icon={<LayoutDashboard />} label="Home" active={location.pathname === '/'} />
            <NavLink to="/search" icon={<SearchIcon />} label="Search" active={location.pathname === '/search'} />
            {user?.is_developer && (
              <NavLink to="/developer" icon={<Shield />} label="Dev Console" active={location.pathname === '/developer'} />
            )}
          </div>

          <div className="flex items-center gap-3">
            {user ? (
              <Link to="/profile" className="flex items-center gap-3 glass pl-2 pr-4 py-1.5 rounded-full hover:bg-white/10 transition-all">
                <img
                  src={user.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.name}`}
                  className="w-8 h-8 rounded-full bg-zinc-800"
                  alt=""
                  referrerPolicy="no-referrer"
                />
                <span className="text-sm font-semibold hidden sm:inline">{user.name}</span>
              </Link>
            ) : (
              <Link to="/auth" className="btn-primary text-sm">Sign In</Link>
            )}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/search" element={<Search />} />
          <Route path="/auth" element={user ? <Home /> : <Auth />} />
          <Route path="/profile" element={user ? <Profile /> : <Auth />} />
          <Route path="/developer" element={user?.is_developer ? <DeveloperDashboard /> : <Home />} />
        </Routes>
      </main>

      {/* Mobile Nav */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 glass border-t border-white/5 px-6 py-3 flex justify-between items-center z-50">
        <MobileNavLink to="/" icon={<LayoutDashboard />} active={location.pathname === '/'} />
        <MobileNavLink to="/search" icon={<SearchIcon />} active={location.pathname === '/search'} />
        {user?.is_developer && (
          <MobileNavLink to="/developer" icon={<Shield />} active={location.pathname === '/developer'} />
        )}
        <MobileNavLink to="/profile" icon={<UserIcon />} active={location.pathname === '/profile'} />
      </div>
    </div>
  );
}

function NavLink({ to, icon, label, active }: { to: string, icon: React.ReactNode, label: string, active: boolean }) {
  return (
    <Link
      to={to}
      className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
        active ? 'bg-emerald-600/10 text-emerald-400' : 'text-zinc-400 hover:text-zinc-100 hover:bg-white/5'
      }`}
    >
      {React.cloneElement(icon as React.ReactElement, { className: 'w-4 h-4' })}
      {label}
    </Link>
  );
}

function MobileNavLink({ to, icon, active }: { to: string, icon: React.ReactNode, active: boolean }) {
  return (
    <Link
      to={to}
      className={`p-2 rounded-xl transition-all ${
        active ? 'text-emerald-400 bg-emerald-600/10' : 'text-zinc-500'
      }`}
    >
      {React.cloneElement(icon as React.ReactElement, { className: 'w-6 h-6' })}
    </Link>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <AppContent />
      </Router>
    </AuthProvider>
  );
}
