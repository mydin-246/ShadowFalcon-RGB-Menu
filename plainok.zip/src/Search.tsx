import React, { useState, useEffect } from 'react';
import { useAuth } from './AuthContext';
import { Game, User } from './types';
import { Search as SearchIcon, Filter, Gamepad2, User as UserIcon, Zap } from 'lucide-react';
import { motion } from 'motion/react';

export default function Search() {
  const [query, setQuery] = useState('');
  const [type, setType] = useState<'all' | 'normal' | 'modded'>('all');
  const [results, setResults] = useState<Game[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const search = async () => {
      setLoading(true);
      try {
        const res = await fetch(`/api/games?q=${query}&type=${type}`);
        setResults(await res.json());
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    };

    const timer = setTimeout(search, 300);
    return () => clearTimeout(timer);
  }, [query, type]);

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      <div className="space-y-6">
        <div className="relative">
          <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-6 h-6 text-zinc-500" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search games, developers, or mods..."
            className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl pl-14 pr-4 py-4 text-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
          />
        </div>

        <div className="flex flex-wrap gap-2">
          {(['all', 'normal', 'modded'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setType(t)}
              className={`px-6 py-2 rounded-full text-sm font-semibold capitalize transition-all ${
                type === t 
                  ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/20' 
                  : 'bg-zinc-900 text-zinc-400 hover:bg-zinc-800'
              }`}
            >
              {t} Games
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {results.map((game) => (
          <motion.div
            key={game.id}
            layout
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="glass rounded-2xl p-4 flex gap-4 items-center"
          >
            <img src={game.icon} className="w-16 h-16 rounded-xl" alt="" referrerPolicy="no-referrer" />
            <div className="flex-1 min-w-0">
              <h3 className="font-bold truncate">{game.title}</h3>
              <p className="text-xs text-zinc-500 truncate">by {game.developer_name}</p>
              <div className="flex gap-2 mt-2">
                <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded uppercase ${
                  game.type === 'modded' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-blue-500/20 text-blue-400'
                }`}>
                  {game.type}
                </span>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded uppercase bg-zinc-800 text-zinc-400">
                  {game.size}
                </span>
              </div>
            </div>
          </motion.div>
        ))}
        {!loading && results.length === 0 && (
          <div className="col-span-full text-center py-20 text-zinc-500">
            No results found for "{query}"
          </div>
        )}
      </div>
    </div>
  );
}
