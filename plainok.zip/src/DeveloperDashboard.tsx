import React, { useState } from 'react';
import { useAuth } from './AuthContext';
import { Upload, Shield, AlertCircle, CheckCircle2, FileCode, HardDrive, Tag } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function DeveloperDashboard() {
  const { user } = useAuth();
  const [file, setFile] = useState<File | null>(null);
  const [scanning, setScanning] = useState(false);
  const [scanResult, setScanResult] = useState<{
    integrity: boolean;
    signature: boolean;
    size: string;
  } | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    type: 'normal' as 'normal' | 'modded',
    version: '1.0.0'
  });

  if (!user?.is_developer) {
    return (
      <div className="flex items-center justify-center h-[80vh]">
        <div className="text-center space-y-4">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto" />
          <h1 className="text-2xl font-bold">Access Denied</h1>
          <p className="text-zinc-500">Only authorized developers can access this page.</p>
        </div>
      </div>
    );
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile && selectedFile.name.endsWith('.apk')) {
      setFile(selectedFile);
      simulateScan(selectedFile);
    } else {
      alert('Please select a valid APK file.');
    }
  };

  const simulateScan = (f: File) => {
    setScanning(true);
    setScanResult(null);
    setTimeout(() => {
      setScanResult({
        integrity: true,
        signature: true,
        size: (f.size / (1024 * 1024)).toFixed(2) + ' MB'
      });
      setScanning(false);
    }, 2000);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!scanResult) return;

    const res = await fetch('/api/games/upload', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...formData,
        developer_id: user.id,
        size: scanResult.size
      }),
    });

    if (res.ok) {
      alert('Game published successfully!');
      setFile(null);
      setScanResult(null);
      setFormData({ title: '', description: '', type: 'normal', version: '1.0.0' });
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-8">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Developer Console</h1>
          <p className="text-zinc-500">Publish and manage your games</p>
        </div>
        <div className="flex items-center gap-3 glass px-4 py-2 rounded-xl">
          <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
          <span className="text-sm font-medium">Verified Developer</span>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-6">
          <form onSubmit={handleSubmit} className="glass rounded-3xl p-8 space-y-6">
            <h2 className="text-xl font-bold flex items-center gap-2">
              <PlusSquare className="w-5 h-5 text-emerald-500" />
              New Game Release
            </h2>

            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-zinc-400">Game Title</label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="input-field"
                  placeholder="e.g. Cyber Runner 2077"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-zinc-400">Description</label>
                <textarea
                  required
                  rows={4}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="input-field resize-none"
                  placeholder="Tell players about your game..."
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-zinc-400">Version</label>
                  <input
                    type="text"
                    required
                    value={formData.version}
                    onChange={(e) => setFormData({ ...formData, version: e.target.value })}
                    className="input-field"
                    placeholder="1.0.0"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-zinc-400">Type</label>
                  <select
                    value={formData.type}
                    onChange={(e) => setFormData({ ...formData, type: e.target.value as any })}
                    className="input-field"
                  >
                    <option value="normal">Normal</option>
                    <option value="modded">Modded</option>
                  </select>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-zinc-400">APK File</label>
                <div className="relative group">
                  <input
                    type="file"
                    accept=".apk"
                    onChange={handleFileChange}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                  />
                  <div className={`border-2 border-dashed rounded-2xl p-8 text-center transition-all ${
                    file ? 'border-emerald-500 bg-emerald-500/5' : 'border-zinc-800 group-hover:border-zinc-700'
                  }`}>
                    <Upload className={`w-10 h-10 mx-auto mb-3 ${file ? 'text-emerald-500' : 'text-zinc-600'}`} />
                    <p className="text-sm font-medium">{file ? file.name : 'Click or drag APK to upload'}</p>
                    <p className="text-xs text-zinc-500 mt-1">Maximum file size: 2GB</p>
                  </div>
                </div>
              </div>
            </div>

            <button
              type="submit"
              disabled={!scanResult || scanning}
              className="w-full btn-primary py-4 text-lg shadow-xl shadow-emerald-900/20 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Publish Game
            </button>
          </form>
        </div>

        <div className="space-y-6">
          <div className="glass rounded-3xl p-6 space-y-6">
            <h3 className="font-bold flex items-center gap-2">
              <Shield className="w-4 h-4 text-blue-500" />
              Security Scan
            </h3>
            
            <AnimatePresence mode="wait">
              {scanning ? (
                <motion.div
                  key="scanning"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="space-y-4"
                >
                  <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
                    <motion.div
                      className="h-full bg-emerald-500"
                      animate={{ x: ['-100%', '100%'] }}
                      transition={{ repeat: Infinity, duration: 1.5, ease: 'linear' }}
                    />
                  </div>
                  <p className="text-xs text-center text-zinc-500">Analyzing package contents...</p>
                </motion.div>
              ) : scanResult ? (
                <motion.div
                  key="result"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="space-y-4"
                >
                  <ScanItem icon={<CheckCircle2 className="text-emerald-500" />} label="Integrity Check" status="Passed" />
                  <ScanItem icon={<FileCode className="text-emerald-500" />} label="Signature" status="Valid" />
                  <ScanItem icon={<HardDrive className="text-emerald-500" />} label="File Size" status={scanResult.size} />
                  <div className="p-3 bg-emerald-500/10 rounded-xl border border-emerald-500/20">
                    <p className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider">Safety Status</p>
                    <p className="text-sm font-semibold text-emerald-500">Secure to Publish</p>
                  </div>
                </motion.div>
              ) : (
                <div className="text-center py-8 space-y-2">
                  <AlertCircle className="w-8 h-8 text-zinc-700 mx-auto" />
                  <p className="text-xs text-zinc-500">Upload an APK to start the security scan</p>
                </div>
              )}
            </AnimatePresence>
          </div>

          <div className="glass rounded-3xl p-6 space-y-4">
            <h3 className="font-bold">Stats</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-zinc-900 rounded-2xl">
                <p className="text-[10px] text-zinc-500 uppercase font-bold">Followers</p>
                <p className="text-xl font-bold">1</p>
              </div>
              <div className="p-4 bg-zinc-900 rounded-2xl">
                <p className="text-[10px] text-zinc-500 uppercase font-bold">Subs</p>
                <p className="text-xl font-bold">1B</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ScanItem({ icon, label, status }: { icon: React.ReactNode, label: string, status: string }) {
  return (
    <div className="flex items-center justify-between p-3 bg-zinc-900/50 rounded-xl">
      <div className="flex items-center gap-3">
        {icon}
        <span className="text-xs text-zinc-400">{label}</span>
      </div>
      <span className="text-xs font-bold">{status}</span>
    </div>
  );
}

function PlusSquare(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect width="18" height="18" x="3" y="3" rx="2" />
      <path d="M8 12h8" />
      <path d="M12 8v8" />
    </svg>
  );
}
