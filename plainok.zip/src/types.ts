export interface User {
  id: number;
  email: string;
  name: string;
  avatar?: string;
  is_developer: number;
  created_at: string;
}

export interface Game {
  id: number;
  title: string;
  description: string;
  icon: string;
  apk_url: string;
  type: 'normal' | 'modded';
  developer_id: number;
  developer_name: string;
  downloads: number;
  size: string;
  version: string;
  created_at: string;
}

export interface Post {
  id: number;
  developer_id: number;
  developer_name: string;
  developer_avatar?: string;
  content: string;
  image?: string;
  created_at: string;
}
