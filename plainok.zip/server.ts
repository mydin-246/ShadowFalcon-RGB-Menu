import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("plainok.db");

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE,
    password TEXT,
    name TEXT,
    avatar TEXT,
    is_developer INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS games (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    description TEXT,
    icon TEXT,
    apk_url TEXT,
    type TEXT, -- 'normal' or 'modded'
    developer_id INTEGER,
    downloads INTEGER DEFAULT 0,
    size TEXT,
    version TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(developer_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    developer_id INTEGER,
    content TEXT,
    image TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(developer_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS complaints (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    type TEXT,
    content TEXT,
    game_id INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS follows (
    follower_id INTEGER,
    developer_id INTEGER,
    PRIMARY KEY(follower_id, developer_id)
  );
`);

// Seed Developers
const devEmails = ['dndjr4779@gmail.com', 'zoka45362@gmail.com'];
const insertUser = db.prepare('INSERT OR IGNORE INTO users (email, name, is_developer) VALUES (?, ?, 1)');
devEmails.forEach(email => {
  insertUser.run(email, email.split('@')[0]);
});

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/games", (req, res) => {
    const { type, q } = req.query;
    let query = `
      SELECT g.*, u.name as developer_name 
      FROM games g 
      JOIN users u ON g.developer_id = u.id
    `;
    const params = [];
    
    if (type || q) {
      query += " WHERE 1=1";
      if (type && type !== 'all') {
        query += " AND g.type = ?";
        params.push(type);
      }
      if (q) {
        query += " AND (g.title LIKE ? OR u.name LIKE ?)";
        params.push(`%${q}%`, `%${q}%`);
      }
    }
    
    query += " ORDER BY g.created_at DESC";
    const games = db.prepare(query).all(...params);
    res.json(games);
  });

  app.get("/api/developers", (req, res) => {
    const developers = db.prepare(`
      SELECT id, name, avatar, email 
      FROM users 
      WHERE is_developer = 1
    `).all();
    res.json(developers);
  });

  app.get("/api/posts", (req, res) => {
    const posts = db.prepare(`
      SELECT p.*, u.name as developer_name, u.avatar as developer_avatar
      FROM posts p
      JOIN users u ON p.developer_id = u.id
      ORDER BY p.created_at DESC
    `).all();
    res.json(posts);
  });

  app.post("/api/auth/login", (req, res) => {
    const { email, password } = req.body;
    // Simple simulation for demo
    let user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
    if (!user) {
      db.prepare('INSERT INTO users (email, name, is_developer) VALUES (?, ?, ?)').run(
        email, 
        email.split('@')[0], 
        devEmails.includes(email) ? 1 : 0
      );
      user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
    }
    res.json({ user });
  });

  app.post("/api/games/upload", (req, res) => {
    const { title, description, type, developer_id, size, version } = req.body;
    const result = db.prepare(`
      INSERT INTO games (title, description, type, developer_id, size, version, icon)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(title, description, type, developer_id, size, version, 'https://picsum.photos/seed/game/200');
    res.json({ id: result.lastInsertRowid });
  });

  app.post("/api/complaints", (req, res) => {
    const { user_id, type, content, game_id } = req.body;
    db.prepare(`
      INSERT INTO complaints (user_id, type, content, game_id)
      VALUES (?, ?, ?, ?)
    `).run(user_id, type, content, game_id);
    res.json({ success: true });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
